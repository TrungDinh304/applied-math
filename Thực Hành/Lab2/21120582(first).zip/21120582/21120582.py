import numpy as np

#hàm theo yêu cầu đề bài:
#tính giá trị tích vô hướng 2 vector
def innerproduct(v1, v2):
    l1=len(v1)
    l2=len(v2)
    if(l2!=l1):#kiểm tra 2 vector có đủ điều kiện để thực hiện phép tính hay không
        print('======================================================================================')
        print('|Tham số truyền vào không hợp lệ do 2 vector truyền vào có chiều dài không giống nhau|')
        print('======================================================================================')
        exit()
    result = 0.
    for i in range(l1):
        result += v1[i] * v2[i]
    return result
#hàm tính độ dài vector
def module(v):
    result=0
    for i in range(len(v)):
        result += v[i]**2
    result = result**(1/2)
    return result
#đưa cá giá trị xấp xỉ 0 về 0 để tiện cho việc biểu diễn 
def xulimatran(A):
    r,c = A.shape
    for i in range(r):
        for j in range(c):
            if abs(A[i][j])<1e-10:
                A[i][j] = 0

#thuật toán GramSchmidt để tìm ta ma trận Q
def GramSchmidtProcess(A):
    rows,cols = A.shape
    temp = A.T
    result = np.zeros([cols,rows])
    for i in range(cols):
        result[i]=temp[i]
        for j in range(0,i):
            result[i] -= (innerproduct(temp[i],result[j])/module(result[j]))*result[j]
        result[i] /= module(result[i])
    result=result.T
    xulimatran(result)
    return result

#hàm theo yêu cầu đề bài:
# Trả về ma trận phân rã Q, R
def QR_factorization(A):
    Q = GramSchmidtProcess(A)
    R = Q.T @ A
    xulimatran(R)
    return (Q, R)

def main():
    #đọc ma trận từ file input
    A = np.loadtxt('INPUT.txt')
    print('Ma Trận A đọc được: \n',A)
    Q,R = QR_factorization(A)
    print('Ma trận phân rã QR của A: A=QR')
    print('========Q========\n',Q)
    print('========R========\n',R)
main()
